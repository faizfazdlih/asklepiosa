package Kesehatan.Asklepios.controller.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import Kesehatan.Asklepios.model.Transaction;
import Kesehatan.Asklepios.model.User;
import Kesehatan.Asklepios.service.TransactionService;
import Kesehatan.Asklepios.service.UserService;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/client/transactions")
public class ClientTransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private UserService userService;

    // Menampilkan semua transaksi client
    @GetMapping
    public String listTransactions(Model model, Principal principal) {
        String email = principal.getName();
        User client = userService.getByEmail(email);
        
        List<Transaction> transactions = transactionService.getTransactionsByClient(client.getId());
        model.addAttribute("transactions", transactions);
        return "client/transactions/list";
    }

    // Menampilkan detail transaksi
    @GetMapping("/{id}")
    public String viewTransaction(@PathVariable String id, Model model, Principal principal) {
        String email = principal.getName();
        User client = userService.getByEmail(email);
        
        Transaction transaction = transactionService.getById(id);
        
        // Pastikan transaksi ini milik client yang sedang login
        if (!transaction.getConsultation().getClient().getId().equals(client.getId())) {
            return "redirect:/client/transactions";
        }
        
        model.addAttribute("transaction", transaction);
        model.addAttribute("paymentMethods", Transaction.PaymentMethod.values());
        return "client/transactions/detail";
    }

    // Proses pembayaran
    @PostMapping("/{id}/pay")
    public String processPayment(
            @PathVariable String id,
            @RequestParam("paymentMethod") String paymentMethod,
            Principal principal) {
        
        String email = principal.getName();
        User client = userService.getByEmail(email);
        
        Transaction transaction = transactionService.getById(id);
        
        // Pastikan transaksi ini milik client yang sedang login
        if (!transaction.getConsultation().getClient().getId().equals(client.getId())) {
            return "redirect:/client/transactions";
        }
        
        // Update metode pembayaran
        transaction.setPaymentMethod(Transaction.PaymentMethod.valueOf(paymentMethod));
        transactionService.updatePaymentStatus(id, Transaction.Status.PAID, java.time.LocalDateTime.now());
        
        return "redirect:/client/transactions/" + id;
    }
}