package Kesehatan.Asklepios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsklepiosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsklepiosApplication.class, args);
	}

}
